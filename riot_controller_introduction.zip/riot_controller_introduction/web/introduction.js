'use strict';
const introEsc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const introPage=document.getElementById('introPage');
const notice=document.getElementById('demoNotice');
let introBusy=false,introWriting=false,introState=null;
const introOpen=new Map();
function introValue(t){return typeof t.value==='boolean'?(t.value?'ON':'OFF'):String(t.value);}
function quality(q){return '<span class="'+(q==='GOOD'?'good':'bad')+'">'+introEsc(q)+'</span>';}
function help(message){return '<details class="help"><summary>Help ?</summary><p>'+introEsc(message)+'</p></details>';}
function section(id,title,content,open=false){return '<details class="card" data-intro-sec="'+id+'" '+(open?'open':'')+'><summary><b>'+introEsc(title)+'</b></summary>'+content+'</details>';}
function link(path,label){return '<a href="'+path+'">'+introEsc(label)+'</a>';}
function readonly(message){return '<p class="readOnly">'+introEsc(message)+' Read-only introduction example; no field write is available.</p>';}
async function introRequest(path,params){
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),5000);
 try{const r=await fetch(path,{cache:'no-store',signal:controller.signal,...(params?{method:'POST',body:new URLSearchParams(params)}:{})});const data=await r.json();if(!r.ok||data.ok===false)throw Error(data.error||('HTTP '+r.status));return data;}finally{clearTimeout(timer);}
}
function devices(s){return '<div class="deviceGrid">'+s.devices.map(d=>{
 const count=s.tags.filter(t=>t.device===d.id&&t.selected).length;
 return '<article class="card"><div class="introHead"><h3>'+link('/device?id='+d.id,d.name)+'</h3>'+quality(d.online?'GOOD':'BAD')+'</div><p>'+introEsc(d.online?'ONLINE':'OFFLINE')+' · '+introEsc(d.address)+'</p><p class="meta">'+count+' selected / active Device Tags</p></article>';
}).join('')+'</div>';}
function library(s){return help('Device Library contains Device Types. Install a Device Type, then create a Device instance and select its Device Tags. The catalog here is illustrative, not a field-validation claim.')+'<div class="deviceGrid">'+s.profiles.map(p=>'<article class="card"><h3>'+introEsc(p.name)+'</h3><p>Vendor: '+introEsc(p.vendor)+'<br>Model: '+introEsc(p.model)+'<br>Profile ID: '+introEsc(p.id)+'</p><p><b>'+p.available+' Available Tags</b></p><p class="meta">'+introEsc(p.validation)+'</p></article>').join('')+'</div>'+readonly('TOML upload, profile editing, and hardware installation are not implemented.');
}
function deviceDetail(s){
 const id=new URLSearchParams(location.search).get('id'),d=s.devices.find(x=>x.id===id);
 if(!d)return '<h1>Device unavailable</h1>'+link('/devices','Return to Devices');
 const profile=s.profiles.find(p=>p.id===d.profile),tags=s.tags.filter(t=>t.device===id);
 let html='<div class="introHead"><h1>'+introEsc(d.name)+'</h1>'+quality(d.online?'GOOD':'BAD')+'</div><p>Device Type: '+introEsc(profile.name)+' · '+introEsc(d.address)+'</p><div class="introHead"><p>'+introEsc(d.online?'ONLINE':'OFFLINE')+' · '+tags.length+' selected / active Device Tags</p><button data-device="'+id+'" data-online="'+(d.online?0:1)+'">Simulate '+(d.online?'Offline':'Online')+'</button></div>'+help('Devices are equipment installed at this site. Choose a Device Type from Device Library, configure communications, and select Device Tags. All values and output actions in this package are simulated.');
 for(const pool of new Set(tags.map(t=>t.pool))){
  html+=section('pool-'+id+'-'+pool,pool,'<div class="deviceTags">'+tags.filter(t=>t.pool===pool).map(t=>{
   const assigned=s.dashboard.items.find(i=>i.ref===t.ref);
   const output=d.driver==='m31'&&/^do[1-4]$/.test(t.id);
   return '<div class="tagRow"><b>'+introEsc(t.name)+'</b><span>'+introEsc(introValue(t))+' '+introEsc(t.units)+'</span>'+quality(t.quality)+'<div class="actions">'+(output?'<button data-do="'+t.id.slice(2)+'" data-value="'+(t.value?0:1)+'" '+(!d.online?'disabled':'')+'>Simulate '+(t.value?'OFF':'ON')+'</button>':'')+'<label><input type="checkbox" data-dashboard="'+introEsc(t.ref)+'" '+(assigned&&assigned.visible?'checked':'')+'>Dashboard</label></div><small>'+introEsc(t.ref)+(t.quality==='BAD'?' · last-known value; Device offline':'')+'</small></div>';
  }).join('')+'</div>',true);
 }
 return html+'<p>'+link('/dashboard-layout','Configure Dashboard groups and assignments')+'</p>'+readonly('Communications fields and Tag selection are examples, not a driver configuration editor.');
}
function flow(s){
 const flow=s.tags.find(t=>t.id==='flow_rate'),total=s.tags.find(t=>t.id==='grand_total');
 return '<h1>Flow</h1><article class="card"><h2>Sales Gas</h2><div class="metrics"><div><small>Flow rate</small><b>'+flow.value+' E3m3/day</b></div><div><small>Daily volume (example)</small><b>12.34 E3m3</b></div><div><small>Hourly volume (example)</small><b>1.025 E3m3</b></div><div><small>Grand Total</small><b>'+total.value+' E3m3</b></div></div>'+quality(flow.quality)+'<p>Run state: '+(flow.quality==='GOOD'?'FLOWING':'SOURCE UNAVAILABLE')+'</p></article>'+help('Flow values may be placed in operator-selected Dashboard groups. Sources do not dictate the display group.')+readonly('No Flow calculation engine or custody-transfer calculation is running. Values do not accumulate in this first pass.');
}
function alarms(s){return '<h1>Alarms</h1>'+help('GOOD/BAD is source quality, not an alarm acknowledgement. This introduction demonstrates a high-temperature alarm and communication failures without running the firmware alarm engine.')+(s.alarms.length?s.alarms.map(a=>'<article class="card"><h2 class="bad">'+introEsc(a.name)+'</h2><p>'+a.value+' deg C > '+a.threshold+' deg C · ACTIVE</p></article>').join(''):'<article class="card">No active simulated process alarms.</article>')+s.devices.filter(d=>!d.online).map(d=>'<article class="card"><b class="bad">'+introEsc(d.name)+' communication unavailable</b><p>Device Tags are BAD; last-known values remain visible.</p></article>').join('')+readonly('Acknowledgement, alarm configuration, and notifications are not implemented.');}
function history(s){return '<h1>History</h1><article class="card"><h2>Simulated event history</h2>'+s.events.map(e=>'<p><span class="muted">'+introEsc(e.time)+' UTC</span> · '+introEsc(e.message)+'</p>').join('')+'</article>'+readonly('These are session events, not firmware historical records. No SD archive or history export is provided.');}
function setup(s){return '<h1>Setup</h1>'+
 section('site','Site','<p><b>'+introEsc(s.site.name)+'</b><br>'+introEsc(s.site.location)+'</p>'+readonly('Site metadata'),true)+
 section('library','Device Library',library(s),true)+
 section('devices','Devices',help('Create Devices from installed Device Types, configure communications, then select Device Tags.')+devices(s)+'<p>'+link('/devices','Installed Devices')+' · '+link('/tag-manager','Tags')+'</p>',true)+
 section('communications','Communications','<p>Ethernet: SIMULATED<br>Wi-Fi: OFFLINE<br>MQTT: not connected</p>'+readonly('No network scanning, Modbus transport, or MQTT client exists.'))+
 section('display','Display','<p>'+link('/dashboard-layout','Dashboard Layout')+'</p>'+help('Source determines where a value comes from. Dashboard configuration determines where it appears. A group may mix values from different Devices.'))+
 section('flow','Flow','<p>'+link('/flow','View Sales Gas flow example')+'</p>')+
 section('history','History','<p>'+link('/history','View session history')+'</p>')+
 section('alarms','Alarms','<p>'+link('/alarms','View simulated alarms')+'</p>')+
 section('advanced','Advanced',readonly('Advanced controller settings'));
}
function maintenance(s){return '<h1>Maintenance</h1>'+[
 ['backup','Backup & Restore','No controller backup is generated or restored. Demo edits are saved in state/current_state.json. Reset Demo restores the selected scenario baseline.'],
 ['firmware','Firmware','WEB1 is not firmware. Flashing, uploading, and firmware replacement are unavailable.'],
 ['storage','Storage','Simulation: local JSON state, restored on restart. No LittleFS or SD card is accessed.'],
 ['diagnostics','Diagnostics',s.devices.map(d=>d.name+': '+(d.online?'ONLINE':'OFFLINE')+' | good '+d.good+' / bad '+d.bad).join('\n')],
 ['logs','Logs',s.events.map(e=>e.time+' UTC | '+e.message).join('\n')],
 ['advanced','Advanced','No real device write, reset, format, or network-scan action exists.']
 ].map(([id,name,body])=>section(id,name,'<pre>'+introEsc(body)+'</pre>'+readonly('Simulated/read-only'),id==='diagnostics')).join('');}
function apiPage(){return '<h1>API</h1><p>Local simulated responses only. These are a subset, not a complete RIOT API contract.</p><article class="card">'+['/api/hmi','/status','/api/time','/api/modbus','/api/library-signals','/tags','/api/dashboard-layout','/api/sim/state'].map(path=>'<p>'+link(path,path)+'</p>').join('')+'</article>'+readonly('Output and scenario POSTs modify only this introduction process.');}
function renderIntro(s){
 if(!introPage)return;
 const renderers={'/setup':setup,'/devices':x=>'<h1>Devices</h1>'+help('Installed Device instances belong to this site. Device Library holds reusable Device Types.')+devices(x),'/device-library':x=>'<h1>Device Library</h1>'+library(x),'/device':deviceDetail,'/flow':flow,'/alarms':alarms,'/history':history,'/maintenance':maintenance,'/api-reference':apiPage,'/rules':()=>'<h1>Rules</h1>'+section('rules','Burner permissive example','<p>If Flame Detected is GOOD and ON, display Burner Run status.</p>'+readonly('Illustrative rule only; no rule engine or output automation runs.'),true),'/tag-manager':x=>'<h1>Tags</h1>'+x.tags.map(t=>'<div class="card">'+introEsc(t.name)+' · '+introEsc(introValue(t))+' '+introEsc(t.units)+' · '+quality(t.quality)+'</div>').join('')};
 introPage.innerHTML=(renderers[location.pathname]||(()=>'<h1>Page unavailable</h1>'))(s);
 introPage.querySelectorAll('details[data-intro-sec]').forEach(d=>{
  const key=location.pathname+location.search+':'+d.dataset.introSec;
  if(introOpen.has(key))d.open=introOpen.get(key);
  d.addEventListener('toggle',()=>introOpen.set(key,d.open));
 });
}
async function refreshIntro(){
 if(introBusy||introWriting||document.activeElement?.closest('#introPage'))return;
 introBusy=true;
 try{introState=await introRequest('/api/sim/state');document.getElementById('scenario').value=introState.scenario;renderIntro(introState);}
 catch(err){notice.textContent='Simulation data unavailable: '+err.message;notice.classList.add('bad');}
 finally{introBusy=false;}
}
async function writeIntro(path,params,reload=false){
 if(introWriting)return;introWriting=true;
 try{await introRequest(path,params);notice.textContent='Simulated change saved';notice.classList.remove('bad');if(reload){location.reload();return;}introState=await introRequest('/api/sim/state');renderIntro(introState);}
 catch(err){notice.textContent='Simulated action failed: '+err.message;notice.classList.add('bad');if(introState)document.getElementById('scenario').value=introState.scenario;await refreshAfterFailure();}
 finally{introWriting=false;}
}
async function refreshAfterFailure(){try{introState=await introRequest('/api/sim/state');renderIntro(introState);}catch(err){notice.textContent+='; refresh failed: '+err.message;}}
function allowScenario(){
 // The extracted layout owns its unsaved-draft guard.
 if(location.pathname==='/dashboard-layout'&&(typeof dlDirty!=='undefined'&&(dlDirty||dlSaving))){notice.textContent='Save Dashboard Layout changes before switching or resetting the demo.';return false;}
 return true;
}
document.getElementById('scenario').addEventListener('change',ev=>{if(!allowScenario()){ev.target.value=introState?.scenario||'normal_site';return;}writeIntro('/sim/scenario',{scenario:ev.target.value},true);});
document.getElementById('resetDemo').addEventListener('click',()=>{if(allowScenario()&&confirm('Reset all simulated Devices and Dashboard settings to the selected scenario baseline?'))writeIntro('/sim/reset',{},true);});
document.getElementById('theme').addEventListener('change',ev=>{document.documentElement.dataset.theme=ev.target.value;});
introPage?.addEventListener('click',ev=>{
 const button=ev.target.closest('button');if(!button)return;
 if(button.dataset.do)writeIntro('/m31/output/do',{ch:button.dataset.do,value:button.dataset.value});
 if(button.dataset.device)writeIntro('/sim/device',{id:button.dataset.device,online:button.dataset.online});
});
introPage?.addEventListener('change',ev=>{if(ev.target.dataset.dashboard)writeIntro('/sim/tag-dashboard',{ref:ev.target.dataset.dashboard,visible:ev.target.checked?'1':'0'});});
document.querySelectorAll('nav a').forEach(a=>{if(a.getAttribute('href')===location.pathname)a.setAttribute('aria-current','page');});
(async()=>{try{const result=await introRequest('/api/sim/scenarios');document.getElementById('scenario').innerHTML=result.scenarios.map(s=>'<option value="'+introEsc(s.id)+'">'+introEsc(s.name)+'</option>').join('');await refreshIntro();document.getElementById('scenario').disabled=false;document.getElementById('resetDemo').disabled=false;}catch(err){notice.textContent='Could not initialize introduction: '+err.message;notice.classList.add('bad');}})();
setInterval(refreshIntro,2000);
