# RIOT Controller Introduction

An offline, Windows-first introduction to the RIOT controller. Explore a simulated
gas well, Device Library, Devices and Device Tags without controller hardware.
**No field equipment is connected. Every write affects demo memory only.**

## Run on Windows

1. Extract the complete package to a folder.
2. Install Python **3.10 or newer** if needed. Enable the Python launcher or
   "Add Python to PATH" during installation. No Python packages are required.
3. Double-click `start.bat`. Keep its console window open.
4. The browser opens **http://127.0.0.1:8080**. If it does not, open that URL yourself.

If port 8080 is occupied, run `start.bat --port 8081` from a terminal.
Use `start.bat --no-browser` to avoid automatic browser opening.
Stop with **Ctrl+C** in the server console (or close that console).
Alternatively run `python server.py --open`.

## Try it

- Explore Dashboard, then Setup -> Devices -> M31 Rack.
- Toggle simulated DO1..DO4 and return to Dashboard to see the change.
- Try **Burner Offline**, **M31 Communication Failure**, or **High Process Alarm**
  or **NGC Offline** using the Scenario selector. Communication failures show BAD quality and
  last-known values; offline M31 output commands are refused.
- Choose an installed Device as Primary I/O, edit groups and item assignments
  under Setup -> Display -> Dashboard Layout, then **Save Changes**.
- **Reset Demo** restores the **selected scenario baseline** and clears its demo edits.

Scenario changes reset simulated values and layout to that scenario baseline. JSON scenario files live in
`scenarios/`: `normal_site.json` supplies the base site; the other files supply
offline Devices and value overrides. Edits are saved automatically in
`state/current_state.json` and restored on server restart. The state file is created
on first launch and includes the selected scenario, Device online states, Tag
values, Dashboard settings and recent demo events. Uptime starts fresh each run.
Writes use a temporary file and atomic replacement; failed saves retain the prior
memory/disk state and show an error. Invalid saved state stops startup and is
retained: move it aside manually to start a fresh demo, or correct it before retrying.
Use a writable extracted folder. Do not enter real passwords or site secrets.

## Offline and isolation

All browser assets are included. There are no CDNs, external fonts, APIs, network
scans, Modbus/MQTT clients, or hardware writes. The server binds **127.0.0.1 only**.
The displayed Device IPs are documentation examples and are never contacted.
The clock is the local server's UTC clock, labelled as simulated, not RIOT time.
Normal operation requires neither repository source nor firmware toolchains.
Distribute this whole folder, including generated assets and scenario files.

## Presentation reuse / maintenance

`sync_ui.py` extracts assets from the current
`trmnl_controller/src/p4_nano_p3b2.cpp` without changing firmware:

| Generated file | Source |
|---|---|
| `web/riot.css` | Nano `CSS` common HMI raw literal |
| `web/dashboard.html` | `DASHC` plus `UXJ` collapse helper |
| `web/dashboard-layout.html` | `DBLAY` configuration UI and its real browser JS |

From this folder, a maintainer runs `python sync_ui.py` after Nano UI changes,
then tests the introduction. Extraction refuses missing or ambiguous markers.
The generated files are shipped in the package; extraction is **not** a startup
requirement. Never hand-edit generated assets.

The shared shell/navigation and introduction-only pages are adapted in
`web/shell.html`, `web/introduction.css`, and `web/introduction.js`.
These pages deliberately simplify the firmware workflows. Drift risk remains in
these adaptations and the server's API subset; re-run tests and browser checks
after regeneration. The simulator mirrors only fields used by the extracted
Dashboard/Layout scripts, not every firmware API field or runtime guarantee.
`/api/sim/state` is the central simulated model.

The header uses the supplied Outlaw Automation logo, copied from
`docs/OAI-LOGO-SMALL.PNG` to `web/OAI-LOGO-SMALL.PNG`. The packaged copy is served
locally and needs no repository access or internet connection.

## First-pass limits

- Profiles/tag counts are illustrative, **not validated production TOML profiles**.
  R44VL04 has a catalog entry only. No TOML upload or Device creation is included.
- No firmware polling, Flow/Tag/Rule/alarm engine, notifications, or totalization.
  Values are scenario samples; displayed flow volumes do not accumulate.
- Maintenance writes (firmware, format, restore) are unavailable, not simulated
  successes. History contains session events only.
- Shared state belongs to one local server; browser tabs share the same demo.
- Layout edits use local simulator JSON, not firmware binary stores or real backup/restore.
- ABB NGC8206 Tags (Methane, Ethane, Heating Value, Analysis Ready) are representative
  examples, not a validated ABB register map, complete gas analysis, or production profile.

## Developer checks

Run `python -m unittest discover -s tests -v`. Tests use temporary loopback servers
and cover API contracts, output isolation, scenarios, and atomic layout drafts.
No PlatformIO build is needed: WEB1 changes no firmware or dependencies.

### First-pass validation (2026-10-10)

Checked on Windows with Python 3.12.10:

- `start.bat --no-browser` launched the loopback server successfully.
- Seven standard-library tests passed.
- Browser navigation, all four scenarios, DO1..DO4 state reflected on Dashboard,
  Reset Demo, and shared Dashboard Layout save were exercised.
- Dashboard and Setup had no horizontal overflow at phone widths down to 320 px.
- Observed browser resource requests used only `http://127.0.0.1:8080`;
  CSS, scripts, fonts and data require no remote service.

Automatic opening of the user's default browser and a clean-computer download/
extract/install flow still need distribution testing. No firmware build,
upload, staging, or commit was performed.

NGC/persistence follow-up: nine tests passed, including saved-state restart,
selected-scenario reset, corrupt-file retention, and simulated disk-write failure
rollback. Live preview checks confirmed NGC Tags/Offline quality, then verified
that an online override survived an actual server restart and Reset Demo restored
NGC Offline (not Normal Site). Runtime JSON is ignored by Git and should not be
included in a clean distribution. Tests use isolated temporary files.
